var fingrChords = (function(){
	
	var canvas,
		ctx;

	var leap = new Leap.Controller({enableGestures: false});

	var testBool = true;

	var colors = [{
		r : 255,
		g : 0,
		b : 0,
	},{
		r : 0,
		g : 255,
		b : 0
	},{
		r : 0,
		g : 0,
		b : 0
	},{
		r : 255,
		g : 255,
		b : 0
	},{
		r : 0,
		g : 255,
		b : 255
	},{
		r : 255,
		g : 0,
		b : 255
	},{
		r : 125,
		g : 0,
		b : 125
	},{
		r : 125,
		g : 125,
		b : 0
	},{
		r : 0,
		g : 125,
		b : 125
	},{
		r : 255,
		g : 150,
		b : 0
	},{
		r : 150,
		g : 255,
		b : 150
	}]

	function animate(leapData){

		var cartesianFingers = airPlane.checkCoords(leapData);

		if(cartesianFingers === undefined){
			return;
		}

		//console.log(JSON.stringify(cartesianFingers));
		
		if(cartesianFingers.length > 0){

			var a = 0;

			while(a < cartesianFingers.length){

				var thisPoint = cartesianFingers[a],
					size = 0 - Math.round(thisPoint.z / 10);

				if(size < 1){
					size = 1;
				}

				ctx.fillStyle = "rgb(" + colors[a].r + "," + colors[a].g + ", " + colors[a].b + ")";
				ctx.fillRect(thisPoint.x, thisPoint.y, size, size);

				a += 1;
			}

		}

	}

	function init(){
		//console.log("Hello");
		canvas = document.getElementsByTagName('canvas')[0];
		ctx = canvas.getContext('2d');

		canvas.width = window.innerWidth;
		canvas.height = window.innerHeight;

		airPlane.set({
			customEvent : "click",
			delay : 500,
			displayPointers : true,
			alwaysReset : false,
			returnCoordinates : true
		});

		leap.on('animationFrame', function(frame){
			animate(frame);
		});

		leap.connect();

		var forcedCoords = {
				z : -120,
				top : 250,
				right : 150,
				bottom : 125,
				left : -150
			}

		window.addEventListener('resize', function(){
			canvas.width = window.innerWidth;
			canvas.height = window.innerHeight;
		}. false);

		window.addEventListener('keyup', function(e){
			if(e.keyCode === 32){
				e.preventDefault();
				ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
			}
		}, false);

		canvas.addEventListener('click', function(e){
			console.log("Click");
		}, false);

		var tappables = document.getElementsByClassName('tappable');

		var ax = 0;

		while(ax < tappables.length){

			tappables[ax].addEventListener('click', function(){
				this.style.display = "none";
			}, false);

			ax += 1;
		
		}

	}

	return{
		init : init
	};

})();

(function(){
	fingrChords.init();
})();